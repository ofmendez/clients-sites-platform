const tourDatesUSA = [
  {
    date: "AUG 19",
    city: "SAN JOSE, CA",
    venue: "SAP Center",
    status: "soldout",
    labelStatus: "soldout"
  },
  {
    date: "AUG 21",
    city: "INGLEWOOD, CA",
    venue: "KIA FORUM",
    status: "soldout",
    labelStatus: "soldout"
  },
  {
    date: "AUG 23",
    city: "SAN DIEGO, CA",
    venue: "Viejas Arena",
    status: "soldout",
    labelStatus: "soldout"
  },
  {
    date: "AUG 27",
    city: "HOUSTON, TX",
    venue: "Toyota Center",
    status: "tickets",
    url: "https://www.toyotacenter.com/events/detail/omar-courtz",
    labelStatus: "newvenue"
  },
  {
    date: "AUG 28",
    city: "IRVING, TX",
    venue: "Toyota Music Factory",
    status: "soldout",
    labelStatus: "soldout"
  },
  {
    date: "AUG 30",
    city: "ATLANTA, GA",
    venue: "Gas South Arena",
    status: "tickets",
    url: "https://www.ticketmaster.com/event/0E006479E4D7F324",
    labelStatus: "newtickets"
  },
  {
    date: "SEP 02",
    city: "WASHINGTON, DC",
    venue: "CFG Arena",
    status: "tickets",
    url: "https://www.ticketmaster.com/event/150064A2C0D8A6B7",
    labelStatus: "newvenue"
  },
  {
    date: "SEP 03",
    city: "BOSTON, MA",
    venue: "MGM Music Hall @ Fenway",
    status: "soldout",
    labelStatus: "soldout"
  },
  {
    date: "SEP 05",
    city: "CHICAGO, IL",
    venue: "United Center",
    status: "tickets",
    url: "https://www.ticketmaster.com/event/0400649EDE1DE3C2",
    labelStatus: "newvenue"
  },
  {
    date: "SEP 08",
    city: "BROOKLYN, NY",
    venue: "Barclays Center",
    status: "soldout",
    labelStatus: "soldout"
  },
  {
    date: "SEP 09",
    city: "BROOKLYN, NY",
    venue: "Barclays Center",
    status: "soldout",
    labelStatus: "soldout"
  },
  {
    date: "SEP 10",
    city: "READING, PA",
    venue: "Santander Arena",
    status: "soldout",
    labelStatus: "soldout"
  },
  {
    date: "SEP 11",
    city: "MIAMI, FL",
    venue: "Kaseya Center",
    status: "soldout",
    labelStatus: "soldout"
  },
  {
    date: "SEP 12",
    city: "MIAMI, FL",
    venue: "Kaseya Center",
    status: "soldout",
    labelStatus: "soldout"
  },
  {
    date: "SEP 13",
    city: "ORLANDO, FL",
    venue: "Kia Center",
    status: "soldout",
    labelStatus: "soldout"
  },
  {
    date: "SEP 19",
    city: "ORLANDO, FL",
    venue: "Kia Center",
    status: "tickets",
    url: "https://www.ticketmaster.com/event/2200649C96423A0B",
    labelStatus: "newvenue"
  },
  {
    date: "SEP 24",
    city: "SAN JUAN, PR",
    venue: "Coliseo de Puerto Rico",
    status: "soldout",
    labelStatus: "soldout"
  },
  {
    date: "SEP 25",
    city: "SAN JUAN, PR",
    venue: "Coliseo de Puerto Rico",
    status: "soldout",
    labelStatus: "soldout"
  },
  {
    date: "SEP 26",
    city: "SAN JUAN, PR",
    venue: "Coliseo de Puerto Rico",
    status: "soldout",
    labelStatus: "soldout"
  },
  {
    date: "SEP 27",
    city: "SAN JUAN, PR",
    venue: "Coliseo de Puerto Rico",
    status: "soldout",
    labelStatus: "soldout"
  },
  {
    date: "SEP 28",
    city: "SAN JUAN, PR",
    venue: "Coliseo de Puerto Rico",
    status: "tickets",
    url: "https://choli.ticketera.com/event/omar-courtz-por-si-manana-no-estoy-9d33cx?_gl=1*tbfb62*_gcl_au*MTAxODM0Njg2Mi4xNzg0MjIzOTgz",
    labelStatus: "newdate"
  }
];

const tourDatesLATAM = [
  {
    date: "OCT 28",
    city: "C. DE MÉXICO, MÉXICO",
    venue: "Palacio de los deportes",
    status: "tickets",
    url: "https://www.ticketmaster.com.mx/omar-courtz-ciudad-de-mexico-28-10-2026/event/140064DEC19B99D4?referrer=https%3A%2F%2Fwww.ticketmaster.com.mx%2Fomar-courtz-boletos%2Fartist%2F3026340",
    labelStatus: "newdate"
  },
  {
    date: "OCT 31",
    city: "GUADALAJARA, MÉXICO",
    venue: "Arena VFG",
    status: "tickets",
    url: "https://www.ticketmaster.com.mx/omar-courtz-tlajomulco-de-zuniga-31-10-2026/event/3D0064DEC2963798?referrer=https%3A%2F%2Fwww.ticketmaster.com.mx%2Fomar-courtz-boletos%2Fartist%2F3026340",
    labelStatus: "newdate"
  },
  {
    date: "NOV 06",
    city: "MONTERREY, MÉXICO",
    venue: "Auditorio Banamex",
    status: "tickets",
    url: "https://www.ticketmaster.com.mx/event/140064DEBF939539",
    labelStatus: "newdate"
  },
  {
    date: "NOV 12",
    city: "BOGOTÁ, COLOMBIA",
    venue: "Movistar Arena",
    status: "tickets",
    url: "https://tuboleta.com/es/eventos/omar-courtz-por-si-manana-no-estoy-2026",
    labelStatus: "newdate"
  },
  {
    date: "NOV 14",
    city: "SAN SALVADOR, EL SALVADOR",
    venue: "Complejo Estadio Cuscatlan",
    status: "tickets",
    url: "https://www.billetix.co/presales/omarcourtz",
    labelStatus: "newdate"
  },
  {
    date: "NOV 20",
    city: "C. DE GUATEMALA, GUATEMALA",
    venue: "Explanada 5",
    status: "tickets",
    url: "https://www.ticketasa.gt/events/omar_courtz",
    labelStatus: "newdate"
  },
  {
    date: "NOV 21",
    city: "SAN JOSÉ, COSTA RICA",
    venue: "Anfiteatro Imperial",
    status: "tickets",
    url: "https://www.eticket.cr/eventos.aspx?idartista=1255",
    labelStatus: "newdate"
  },
  {
    date: "NOV 26",
    city: "PANAMA CITY, PANAMA",
    venue: "Estadio Emilio Royo",
    status: "tickets",
    url: "https://panatickets.boletosenlinea.events/eventperformances.asp?evt=2700",
    labelStatus: "newdate"
  },
  {
    date: "NOV 28",
    city: "LIMA, PERÚ",
    venue: "Arena 1",
    status: "tickets",
    url: "https://www.ticketmaster.pe/event/omar-courtz",
    labelStatus: "newdate"
  },
  {
    date: "DEC 03",
    city: "BUENOS AIRES, ARGENTINA",
    venue: "Movistar Arena",
    status: "tickets",
    url: "https://www.movistararena.com.ar/show/949f1877-625b-479f-893a-1ae09da0f00f",
    labelStatus: "newdate"
  },
  {
    date: "DEC 06",
    city: "SANTIAGO, CHILE",
    venue: "Movistar Arena",
    status: "tickets",
    url: "https://www.puntoticket.com/omar-courtz",
    labelStatus: "newdate"
  },
  {
    date: "DEC 12",
    city: "SANTO DOMINGO, RD",
    venue: "Festival Presidente",
    status: "coming",
    labelStatus: "newdate"
  }
];

const tourRegions = {
  usa: tourDatesUSA,
  latam: tourDatesLATAM
};

const labelMap = {
  newvenue: ["NEW", "VENUE"],
  newdate: ["NEW", "DATE"],
  soldout: ["SOLD", "OUT"],
  newtickets: ["NEW", "TICKETS"],
  lowtickets: ["LOW", "TICKETS"]
};

function createTourLabel(item) {
  if (!item.labelStatus || !labelMap[item.labelStatus]) {
    return `<div class="tour-label"></div>`;
  }

  const [line1, line2] = labelMap[item.labelStatus];

  return `
    <div class="tour-label tour-label--${item.labelStatus}">
      <span>${line1}</span>
      <span>${line2}</span>
    </div>
  `;
}

function createTourAction(item) {
  if (["tickets", "presale"].includes(item.status) && item.url) {
    const buttonText = item.status === "presale" ? "PRE-SALE" : "TICKETS";
    const ariaText =
      item.status === "presale"
        ? `Preventa para ${item.city}`
        : `Tickets para ${item.city}`;

    return `
      <a
        class="tour-btn"
        href="${item.url}"
        target="_blank"
        rel="noopener noreferrer"
        aria-label="${ariaText}"
      >
        <span>${buttonText}</span>
        <img
          class="tour-btn__arrow"
          src="assets/arrow-right.svg"
          alt=""
        >
      </a>
    `;
  }

  if (item.status === "soldout") {
    return `
      <span class="tour-status tour-status--soldout">
        SOLD OUT
      </span>
    `;
  }

  return `
    <span class="tour-status tour-status--coming">
      COMING SOON
    </span>
  `;
}

function renderTourDates(region = "usa") {
  const container = document.getElementById("tourTable");

  if (!container) return;

  const selectedDates = tourRegions[region];

  container.classList.add("is-changing");

  window.setTimeout(() => {
    container.innerHTML = selectedDates.map((item) => `
      <div class="tour-row ${item.status === "soldout" ? "is-soldout" : ""}">
        ${createTourLabel(item)}

        <div class="tour-date">
          <span>${item.date}</span>
        </div>

        <div class="tour-city">${item.city}</div>

        <div class="tour-venue">${item.venue}</div>

        <div class="tour-action">
          ${createTourAction(item)}
        </div>
      </div>
    `).join("");

    container.classList.remove("is-changing");
  }, 140);
}

function initializeTourTabs() {
  const tabs = document.querySelectorAll("[data-tour-region]");

  tabs.forEach((tab) => {
    tab.addEventListener("click", () => {
      const selectedRegion = tab.dataset.tourRegion;

      tabs.forEach((currentTab) => {
        const isActive = currentTab === tab;

        currentTab.classList.toggle("is-active", isActive);
        currentTab.setAttribute(
          "aria-selected",
          isActive ? "true" : "false"
        );
      });

      renderTourDates(selectedRegion);
    });
  });
}

initializeTourTabs();

const activeTab = document.querySelector(
  ".tour-tab.is-active"
);

renderTourDates(
  activeTab?.dataset.tourRegion || "latam"
);